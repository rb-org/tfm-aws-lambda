import boto3
import os
# import json
# from datetime import datetime
from botocore.exceptions import ClientError

client = boto3.client('ec2')
ec2 = boto3.resource('ec2')

region = os.environ['REGION']


def lambda_handler(event, context):
    try:
        print(region)
    except Exception as e:
        print('Error - reason "%s"' % str(e))
